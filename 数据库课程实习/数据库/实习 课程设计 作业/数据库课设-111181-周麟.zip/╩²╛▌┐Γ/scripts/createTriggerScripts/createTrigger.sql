@.\scripts\createTriggerScripts\updateShelterRoomforDelete.sql
@.\scripts\createTriggerScripts\updateShelterRoomforInsert.sql
@.\scripts\createTriggerScripts\updateShelterRoomforUpdate.sql

quit
