@.\scripts\createProcedureScripts\userAndpwd\managerNamePwd.sql
@.\scripts\createProcedureScripts\userAndpwd\userNamePwd.sql
