@.\scripts\createProcedureScripts\vaccinesImfo\addVaccinesImfo.sql
@.\scripts\createProcedureScripts\vaccinesImfo\seeAllVaccinesImfo.sql
@.\scripts\createProcedureScripts\vaccinesImfo\seeVaccinesImfo.sql

quit