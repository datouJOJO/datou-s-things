@.\scripts\createProcedureScripts\animal\addAnimal.sql
@.\scripts\createProcedureScripts\animal\deleteAnimal.sql
@.\scripts\createProcedureScripts\animal\judgeAnimal.sql
@.\scripts\createProcedureScripts\animal\savePic.sql
@.\scripts\createProcedureScripts\animal\SeeAllAnimalImfo.sql
@.\scripts\createProcedureScripts\animal\seeAnimalImfoByNameOrId.sql
@.\scripts\createProcedureScripts\animal\seeImgData.sql
@.\scripts\createProcedureScripts\animal\updataAnimalImfo.sql

