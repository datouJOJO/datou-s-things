declare 
  flag int;
begin
JUDGEUSER('��ͷ',flag);
dbms_output.put_line(flag);
end;