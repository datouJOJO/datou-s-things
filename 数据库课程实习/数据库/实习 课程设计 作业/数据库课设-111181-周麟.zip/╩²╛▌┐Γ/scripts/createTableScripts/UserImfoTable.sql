create table UserImfo(
  userID varchar(3) primary key,
  userName varchar(20),
  pwd varchar(20),
  email varchar(20),
  tel integer,
  ShelterID integer
);
insert into UserImfo values('001','��ͷ','62591102','111@qq.com',110110120,'001');
insert into UserImfo values('002','�仨','62591102','222@qq.com',110110130,'001');
insert into UserImfo values('003','��ʣ','62591102','333@qq.com',110110140,'001');
insert into UserImfo values('004','����','62591102','444@qq.com',110110150,'001');
insert into UserImfo values('005','����','62591102','555@qq.com',110110160,'001');
insert into UserImfo values('006','��ҵ','62591102','666@qq.com',110110170,'002');
insert into UserImfo values('007','����','62591102','777@qq.com',110110180,'002');
insert into UserImfo values('008','�˻�','62591102','888@qq.com',110110190,'002');
insert into UserImfo values('009','����','62591102','888@qq.com',110110200,'002');
insert into UserImfo values('010','����','62591102','888@qq.com',110110210,'003');
insert into UserImfo values('011','�Ӻ�','62591102','888@qq.com',110110220,'003');
insert into UserImfo values('012','����','62591102','888@qq.com',110110230,'003');
insert into UserImfo values('013','���','62591102','888@qq.com',110110240,'003');
insert into UserImfo values('014','ΰ��','62591102','888@qq.com',110110250,'003');
