@.\scripts\createTableScripts\animalImfoTable.sql
@.\scripts\createTableScripts\healthImfoTable.sql
@.\scripts\createTableScripts\managerInfoTable.sql
@.\scripts\createTableScripts\shelterImfoTable.sql
@.\scripts\createTableScripts\UserImfoTable.sql
@.\scripts\createTableScripts\vaccinesImfoTable.sql
exit;
