create table managerImfo(
  managerID varchar(3) primary key,
  managerName varchar(20),
  pwd varchar(20)
);

insert into managerImfo values('000','admin','admin');
insert into managerImfo values('111','С��','admin');